<?php 
include("includes/includedFiles.php"); 
?>


<script>openPage("browse.php")</script>

